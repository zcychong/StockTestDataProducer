package com.example.stocktestdataproducer;

import android.content.Context;
import android.widget.TextView;

/**
 * Created by zcy on 18-8-29.
 */

public class PoingView extends TextView {
    public PoingView(Context context) {
        super(context);
    }
}
