package com.example.stocktestdataproducer;

import android.widget.CheckBox;

import java.util.ArrayList;

/**
 * Created by zcy on 18-8-29.
 */

public interface ProduceInterface {
    ProduceInterface init(ArrayList<Integer> list);
    float produceData(float value, int weight);
    float produceNormalData(float value);
    float produceErrorData(int index);
}
